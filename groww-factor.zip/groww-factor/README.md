# groww-factor — Mutual Fund FAQs (Facts-Only Q&A)

A small **facts-only** FAQ assistant for HDFC mutual fund schemes. It answers
factual questions — expense ratio, exit load, minimum SIP, ELSS lock-in,
riskometer, benchmark, how to download statements — using **only official public
pages** (HDFC MF, SEBI, AMFI), with **one source link in every answer**. It
**refuses** advice / portfolio / performance questions and never accepts personal
data.

> **Facts-only. No investment advice.** groww-factor surfaces data from official
> HDFC MF, SEBI and AMFI pages; figures like NAV, TER and exit load change — always
> verify on the linked source. Not a SEBI-registered adviser.

## Scope

- **AMC:** HDFC Mutual Fund
- **Schemes:** HDFC Large Cap Fund *(formerly HDFC Top 100, renamed 1 Jan 2025)*,
  HDFC Flexi Cap Fund, HDFC ELSS Tax Saver
- **Sources:** 22 official HDFC MF / SEBI / AMFI URLs (in `corpus.json`)

## Features

- Grounded retrieval over a curated corpus — **citations are never hallucinated**.
- Guardrail-first routing: **PII → advice → performance → answer → help → scope**.
- ≤3-sentence answers + one citation + "Last updated from sources: <date>".
- Pure-Python TF-IDF semantic fallback (no ML dependency, fully offline).
- Daily source-verification pipeline (GitHub Actions + optional local scheduler).
- Optional, tightly-constrained LLM rephrasing that **cannot** change a citation.

## Project structure

```
groww-factor/
├── app.py                 # FastAPI server: chat UI + /ask /meta /health
├── retrieval.py           # guardrails + scheme/topic lookup + TF-IDF fallback
├── generate.py            # response composition (+ optional guarded LLM rephrase)
├── corpus.json            # source of truth: sources + 32 fact entries
├── ingest.py              # verify sources, refresh last_verified, write report
├── scheduler.py           # APScheduler daily ingestion (long-running hosts)
├── requirements.txt
├── .env.example           # copy to .env
├── .github/workflows/
│   └── dailyingestion.yml # daily source verification in CI
├── data/                  # verification_report.json (generated)
├── problemStatement.md
├── architecture.md
├── implementation-plan.md
└── edge-case.md
```

## Setup & run

Requires Python 3.10+.

```bash
git clone <your-repo-url> groww-factor
cd groww-factor
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                # defaults are fine

uvicorn app:app --reload --port 8000
# open http://localhost:8000
```

Quick CLI checks (no server needed):

```bash
python retrieval.py "What is the lock-in period for HDFC ELSS Tax Saver?"
python generate.py  "benchmark for HDFC Flexi Cap Fund"
```

## API

| Method | Path | Body / returns |
|--------|------|----------------|
| GET | `/` | Chat UI (single page) |
| POST | `/ask` | `{"query": "..."}` → `{kind, answer, source, last_verified, footer?}` |
| GET | `/meta` | AMC, schemes, last_updated, disclaimer, use_llm |
| GET | `/health` | `{status, entries}` |

Example:
```bash
curl -s localhost:8000/ask -H 'content-type: application/json' \
  -d '{"query":"exit load on HDFC ELSS Tax Saver"}'
```

## Daily ingestion (freshness)

`ingest.py` re-fetches every official source, confirms HTTP 200 + content hash,
restamps `last_verified`, and writes `data/verification_report.json`. It never
auto-writes facts — a human reviews any flagged/changed source before editing an
answer.

```bash
python ingest.py            # verify + restamp
python ingest.py --check    # verify only; non-zero exit if any source fails (CI gate)
python scheduler.py         # run daily via APScheduler
```

The included GitHub Action (`.github/workflows/dailyingestion.yml`) runs the same
verification daily and commits refreshed timestamps. It needs no secrets; it uses
the default `GITHUB_TOKEN` with `contents: write`.

## Optional LLM mode

Set `USE_LLM=true` and `ANTHROPIC_API_KEY=...` in `.env` (and uncomment
`anthropic` in `requirements.txt`). The model only rephrases the retrieved fact
for fluency under tight constraints; the **source link and date are appended by
code**, so a citation can never be invented. Any LLM error falls back to the
template. Default is off.

## Constraints honoured

- **Public sources only** (HDFC MF / SEBI / AMFI); no back-end screenshots, no
  third-party blogs. `ingest.py` enforces an on-domain allow-list.
- **No PII** — detects and refuses PAN/Aadhaar/account/OTP/email/phone; stores nothing.
- **No performance claims** — never computes/compares returns; links to the factsheet.
- **Clarity** — answers ≤3 sentences, one citation, dated.

## Known limits

- Volatile figures (NAV, TER, exact exit load, minimum SIP, current fund manager)
  are **not** hard-coded; the bot returns the concept + the live official link. HDFC's
  flexi/ELSS managers changed twice in late-2025/early-2026, which is exactly why.
- Tiny corpus (3 schemes + listed topics); anything else is correctly refused.
- Rule-based + TF-IDF retrieval; very novel phrasings fall through to a safe
  "rephrase / pick a supported topic" nudge. Swap in embeddings for higher recall.
- Citations are page-level, not deep-linked to a line. English output only.
- Information tool, **not** a SEBI-registered adviser; no suitability assessment.

## Data freshness

Corpus last verified against official sources on **2026-06-04**.
HDFC Top 100 Fund was renamed **HDFC Large Cap Fund** effective **1 Jan 2025**.

## License

MIT (suggested) — add a `LICENSE` file before publishing if required.
