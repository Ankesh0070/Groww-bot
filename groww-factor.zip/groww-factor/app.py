"""
app.py
------
FastAPI server for groww-factor.

Endpoints
  GET  /          -> minimal chat UI (single page)
  POST /ask       -> {"query": "..."} -> grounded, cited answer
  GET  /meta      -> corpus scope + disclaimer
  GET  /health    -> liveness probe

Run:  uvicorn app:app --reload --port 8000
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from generate import Generator

load_dotenv()

BASE = Path(__file__).resolve().parent
generator = Generator(BASE / "corpus.json")

app = FastAPI(title="groww-factor", description="Facts-only Q&A for HDFC Mutual Fund schemes")


class AskRequest(BaseModel):
    query: str


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "entries": len(generator.retriever.entries)}


@app.get("/meta")
def meta() -> dict:
    m = generator.retriever.meta
    return {
        "amc": m["amc"],
        "schemes": m["schemes"],
        "last_updated": m["last_updated"],
        "disclaimer": m["disclaimer"],
        "use_llm": generator.use_llm,
    }


@app.post("/ask")
def ask(req: AskRequest) -> JSONResponse:
    return JSONResponse(generator.respond(req.query))


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return INDEX_HTML


INDEX_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>groww-factor - Mutual Fund FAQs</title>
<style>
  :root{--accent:#15e0a0;--bg:#070809;--panel:#10151a;--text:#e9eef3;--dim:#8b95a3;--faint:#5b6573;--border:rgba(255,255,255,.08)}
  *{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,Segoe UI,Roboto,sans-serif}
  body{background:var(--bg);color:var(--text);height:100vh;display:flex;flex-direction:column}
  header{display:flex;align-items:center;gap:10px;padding:16px 22px;border-bottom:1px solid var(--border)}
  .logo{width:24px;height:24px;border-radius:50%;background:radial-gradient(circle at 30% 30%,#7df0c8,var(--accent) 45%,#38bdf8)}
  .name{font-weight:700}.badge{margin-left:auto;font-size:11px;color:var(--accent);background:rgba(21,224,160,.1);border:1px solid rgba(21,224,160,.25);padding:5px 11px;border-radius:20px}
  #thread{flex:1;overflow-y:auto;padding:24px;max-width:760px;width:100%;margin:0 auto}
  .welcome{text-align:center;color:var(--dim);margin-top:8vh}
  .welcome h1{color:var(--text);font-weight:600;margin-bottom:10px}
  .ex{display:inline-block;margin:6px;padding:9px 13px;border:1px solid var(--border);border-radius:20px;color:var(--text);background:var(--panel);cursor:pointer;font-size:13px}
  .ex:hover{border-color:var(--accent);color:var(--accent)}
  .row{display:flex;margin:16px 0}.row.user{justify-content:flex-end}
  .bubble{padding:12px 16px;border-radius:14px;font-size:14px;line-height:1.6;max-width:80%}
  .bubble.user{background:linear-gradient(135deg,#15e0a0,#11b6f0);color:#04140e}
  .bubble.bot{background:var(--panel);border:1px solid var(--border)}
  .bubble.bot.soft{border-color:rgba(255,170,60,.3);background:rgba(255,170,60,.06)}
  .cite{display:inline-flex;gap:6px;margin-top:10px;font-size:12px;color:var(--accent);text-decoration:none;border:1px solid var(--border);border-radius:8px;padding:6px 10px}
  .footer{display:block;margin-top:8px;font-size:10.5px;color:var(--faint)}
  form{display:flex;gap:8px;max-width:760px;width:100%;margin:0 auto;padding:14px 22px}
  input{flex:1;background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:12px 14px;color:var(--text);font-size:14px;outline:none}
  input:focus{border-color:var(--accent)}
  button{background:linear-gradient(135deg,#15e0a0,#11b6f0);color:#04140e;border:none;border-radius:10px;padding:0 18px;font-weight:600;cursor:pointer}
  .disc{max-width:760px;margin:0 auto 12px;padding:0 22px;text-align:center;font-size:10.5px;color:var(--faint)}
</style></head>
<body>
  <header><span class="logo"></span><span class="name">groww-factor</span>
    <span class="badge">Facts-only &middot; No advice</span></header>
  <div id="thread">
    <div class="welcome" id="welcome">
      <h1>Ask a fact about HDFC schemes</h1>
      <p>HDFC Large Cap, Flexi Cap and ELSS Tax Saver - one official source link in every answer.</p>
      <div style="margin-top:18px">
        <span class="ex" onclick="ask(this.innerText)">What is the lock-in period for HDFC ELSS Tax Saver?</span>
        <span class="ex" onclick="ask(this.innerText)">What is the benchmark for HDFC Flexi Cap Fund?</span>
        <span class="ex" onclick="ask(this.innerText)">How do I download my account statement?</span>
      </div>
      <p style="margin-top:22px;font-size:11.5px">Facts-only. No investment advice.</p>
    </div>
  </div>
  <form onsubmit="event.preventDefault();ask(document.getElementById('q').value)">
    <input id="q" placeholder="Ask a factual question about HDFC schemes..." autocomplete="off"/>
    <button>Send</button>
  </form>
  <div class="disc">Facts-only. No investment advice. Data from official HDFC MF, SEBI and AMFI pages;
    figures like NAV, TER and exit load change - always verify on the linked source.</div>
<script>
const thread=document.getElementById('thread'),welcome=document.getElementById('welcome');
function esc(s){const d=document.createElement('div');d.innerText=s;return d.innerHTML;}
function add(role,html){const r=document.createElement('div');r.className='row '+role;
  r.innerHTML='<div class="bubble '+role+(role==='bot'?' '+(window._soft||''):'')+'">'+html+'</div>';
  thread.appendChild(r);thread.scrollTop=thread.scrollHeight;}
async function ask(q){q=(q||'').trim();if(!q)return;if(welcome)welcome.remove();
  document.getElementById('q').value='';add('user',esc(q));
  const res=await fetch('/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q})});
  const d=await res.json();const refusal=['advice','scope','pii','performance','help'].includes(d.kind);
  window._soft=refusal?'soft':'';let html=esc(d.answer);
  if(d.source)html+='<a class="cite" target="_blank" href="'+d.source.url+'">&#128279; '+esc(d.source.label)+'</a>';
  if(d.footer)html+='<span class="footer">'+esc(d.footer)+'</span>';
  add('bot',html);}
</script>
</body></html>"""


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "8000")))
