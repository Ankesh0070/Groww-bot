# Architecture

groww-factor is a **small-corpus retrieval** assistant (RAG without a vector DB).
It is intentionally simple, deterministic and offline-capable so that **citations
can never be hallucinated** — every answer's text and source link are pulled
verbatim from a hand-curated corpus.

## Components

| File | Responsibility |
|------|----------------|
| `corpus.json` | Source of truth: `sources` (official URLs) + `entries` (facts with citations). |
| `retrieval.py` | Guardrail classification + scheme/topic lookup + TF-IDF fallback. |
| `generate.py` | Wraps retrieval into a presentation payload; optional guarded LLM rephrase. |
| `app.py` | FastAPI server: chat UI + `/ask`, `/meta`, `/health`. |
| `ingest.py` | Re-verifies every source URL and refreshes `last_verified` timestamps. |
| `scheduler.py` | Runs `ingest` daily (APScheduler) for long-running deployments. |
| `.github/workflows/dailyingestion.yml` | Same verification, daily, in CI. |

## Data flow

```
                       ┌──────────────┐
   user query  ─────►  │  app.py /ask │
                       └──────┬───────┘
                              │
                       ┌──────▼───────┐
                       │ generate.py  │  (optional LLM rephrase of FACT text only)
                       └──────┬───────┘
                              │
                       ┌──────▼───────┐
                       │ retrieval.py │
                       └──────┬───────┘
        ┌─────────────────────┼───────────────────────────┐
        │ 1 PII guard         │ 2 advice/opinion           │ 3 performance
        │   → refuse + KYC    │   → refuse + SEBI edu link  │   → refuse + factsheet
        └─────────────────────┼───────────────────────────┘
                              │ (passes guards)
                       ┌──────▼───────────────────────────┐
                       │ 4 retrieve from corpus.json       │
                       │   a. scheme_topic exact key       │
                       │   b. general_topic fallback       │
                       │   c. scheme_category overview     │
                       │   d. TF-IDF cosine fallback       │
                       └──────┬───────────────────────────┘
                              │
                 ┌────────────┴────────────┐
                 │ hit → answer + 1 source  │   miss → "in-scope but vague" help
                 │       + last_verified    │          or out-of-scope refusal
                 └──────────────────────────┘
```

## Retrieval pipeline (priority order)

Guardrails run **before** retrieval — deciding *answer vs. refuse* is the W1 skill:

1. **PII guard** — regex for PAN / Aadhaar / phone / email / OTP / long account
   numbers. If matched: refuse, warn, store nothing.
2. **Advice / opinion / portfolio** — "should I", "buy/sell", "best fund",
   "which is better", "worth it"… → polite facts-only refusal + SEBI investor-
   education link.
3. **Performance / returns** — "returns", "CAGR", "how did it perform"… → no
   performance claims; pointer to the official factsheet.
4. **Retrieval** —
   a. `detect_scheme` + `detect_topic` → exact `scheme_topic` key (e.g. `elss_lockin`);
   b. fall back to `general_topic` (concept answer);
   c. scheme named but no topic → `scheme_category` overview;
   d. otherwise a pure-Python **TF-IDF cosine** match over each entry's
      `question_variants + answer` (threshold-gated).
5. **In-scope but vague** → short nudge listing supported topics.
6. **Out of scope** → "I can't answer that…".

## Why TF-IDF is hand-rolled

No `scikit-learn` / embedding dependency is required: the IDF table and cosine
similarity are computed in pure Python at load time. This keeps the bot fully
offline, deterministic and dependency-light. It is a drop-in seam — swapping in
sentence-embeddings means replacing `Retriever._semantic` only; the corpus,
citations and guardrails are untouched.

## Grounding & citation guarantee

- Answer text for `kind == "answer"` is the corpus `answer` field (optionally
  rephrased by an LLM under tight constraints).
- The **source link and the "Last updated from sources" date are appended by
  code**, keyed to the retrieved entry — the model never emits them. So even with
  `USE_LLM=true`, a citation cannot be fabricated or mismatched.

## Freshness model

Facts are curated from official pages and committed in `corpus.json`. `ingest.py`
re-fetches each source daily (CI or scheduler), confirms HTTP 200 + content hash,
and bumps `last_verified`. Volatile figures (NAV, TER, exact exit load, minimum
SIP, current fund manager) are **not** hard-coded; those entries return the concept
plus a link to the live official page — correct-by-construction freshness.

## Request/response contract

`POST /ask  {"query": "..."}` →
```json
{
  "kind": "answer | advice | performance | pii | help | scope",
  "answer": "≤3-sentence text",
  "source": { "org": "...", "label": "...", "url": "https://..." } ,
  "last_verified": "2026-06-04",
  "footer": "Last updated from sources: 2026-06-04"
}
```
`source` is `null` for `help`/`scope`; `footer` is present only for fact answers.
