# Edge Cases & Expected Behaviour

This doubles as the manual test matrix. Each row is verified by the routing tests
(`python retrieval.py "<query>"`). `kind` is the classifier's decision.

## A. Factual — should ANSWER with one citation + date

| # | Query | kind | Source cited |
|---|-------|------|--------------|
| A1 | What is the lock-in period for HDFC ELSS Tax Saver? | answer | SEBI – Guide to ELSS |
| A2 | What is the benchmark for HDFC Flexi Cap Fund? | answer | HDFC MF – Flexi Cap |
| A3 | How do I download my account statement? | answer | HDFC MF – CAS |
| A4 | Exit load on HDFC ELSS Tax Saver? | answer | HDFC MF – ELSS |
| A5 | Riskometer of HDFC Large Cap Fund? | answer | HDFC MF – Large Cap |
| A6 | Is there an entry load on mutual funds? | answer | HDFC MF (entry load nil) |
| A7 | Capital-gains statement for ITR? | answer | HDFC MF – CAS |
| A8 | Tell me about HDFC Large Cap. | answer | HDFC MF – Large Cap (category) |

## B. Volatile fields — ANSWER but point to the live page (never a stale number)

| # | Query | kind | Behaviour |
|---|-------|------|-----------|
| B1 | Expense ratio of HDFC Large Cap Fund? | answer | concept + TER disclosure link |
| B2 | NAV of HDFC Flexi Cap today? | answer | concept + scheme-page link |
| B3 | Minimum SIP for HDFC schemes? | answer | concept + KIM link |
| B4 | Who is the fund manager of HDFC ELSS? | answer | "check live scheme page" (managers churn) |

## C. Opinion / portfolio — REFUSE + educational link

| # | Query | kind |
|---|-------|------|
| C1 | Should I buy HDFC Flexi Cap or large cap? | advice |
| C2 | Is HDFC ELSS a good investment right now? | advice |
| C3 | Suggest the best HDFC fund for growth. | advice |
| C4 | Is it the right time to redeem? | advice |

## D. Performance / returns — REFUSE + factsheet

| # | Query | kind |
|---|-------|------|
| D1 | What were HDFC Flexi Cap returns over 3 years? | performance |
| D2 | Compare HDFC ELSS vs SBI ELSS performance. | performance |
| D3 | Will HDFC Large Cap grow next year? | advice (forecast → advice rule fires first) |

## E. PII — REFUSE, store nothing

| # | Query | kind |
|---|-------|------|
| E1 | My PAN is ABCDE1234F, pull my statement. | pii |
| E2 | Account number 1234567890 statement please. | pii |
| E3 | My email is a@b.com, send the report. | pii |
| E4 | Phone 9876543210, contact me. | pii |

## F. Out of scope — REFUSE

| # | Query | kind |
|---|-------|------|
| F1 | Cheapest flight Delhi to Goa? | scope |
| F2 | Which stock should I buy? | advice (advice rule) / scope |
| F3 | Tell me about an SBI fund. | scope |

## G. Tricky / disambiguation

| # | Query | kind | Note |
|---|-------|------|------|
| G1 | Difference between HDFC Top 100 and Large Cap? | answer | both map to Large Cap (renamed 1 Jan 2025) |
| G2 | "tax saver lock-in" (no AMC named) | answer | general ELSS lock-in concept |
| G3 | Vague: "HDFC ke bare me batao" | help | in-scope nudge to a supported topic |
| G4 | Typos: "wot is hdfc flexi capp" | answer | TF-IDF fallback recovers it |
| G5 | Long multi-fact: "ELSS lock-in aur exit load?" | answer | returns the first matched topic; ask follow-up for the rest |

## Known false-edge behaviour (documented, acceptable)

- "Capital **gains** statement" must be checked **before** plain "statement" —
  handled by topic-rule ordering (capgains first).
- A forecast phrased as "will it grow" hits the **advice** rule before the
  performance rule; both are refusals, so the outcome is still correct.
- Extremely novel phrasings below the TF-IDF threshold fall through to the
  in-scope `help` nudge rather than guessing — a safe failure mode.
