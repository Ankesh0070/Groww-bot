"""
generate.py
-----------
Turns a retrieval result into the final user-facing response.

Generation is deliberately *grounded*: the answer text comes verbatim from the
curated corpus. An optional LLM mode (USE_LLM=true + ANTHROPIC_API_KEY) can
lightly rephrase the retrieved fact for fluency, but it is constrained to the
retrieved text and the citation/date are appended by code, never by the model -
so a citation can never be hallucinated. Any LLM error falls back to the
template response.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from retrieval import Retriever

FACT_KINDS = {"answer"}


class Generator:
    def __init__(self, corpus_path: str | Path = "corpus.json", use_llm: Optional[bool] = None):
        self.retriever = Retriever(corpus_path)
        env = os.getenv("USE_LLM", "false").strip().lower() in {"1", "true", "yes"}
        self.use_llm = env if use_llm is None else use_llm
        self.model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")
        self._client = None
        if self.use_llm:
            self._init_llm()

    def _init_llm(self) -> None:
        try:
            import anthropic  # noqa
            key = os.getenv("ANTHROPIC_API_KEY")
            if key:
                self._client = anthropic.Anthropic(api_key=key)
            else:
                self.use_llm = False
        except Exception:
            self.use_llm = False

    def _rephrase(self, fact: str) -> str:
        """Constrained, citation-free rephrase. Returns fact unchanged on any issue."""
        if not self._client:
            return fact
        try:
            sys_prompt = (
                "You rephrase a single factual sentence about a mutual fund for clarity. "
                "Rules: keep it factual and <=3 sentences, do not add numbers, claims, opinions, "
                "URLs or citations, do not invent anything not in the input. Output only the rephrased fact."
            )
            msg = self._client.messages.create(
                model=self.model,
                max_tokens=300,
                system=sys_prompt,
                messages=[{"role": "user", "content": fact}],
            )
            out = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
            return out or fact
        except Exception:
            return fact

    def respond(self, query: str) -> dict:
        res = self.retriever.answer(query)
        if self.use_llm and res["kind"] in FACT_KINDS:
            res = dict(res)
            res["text"] = self._rephrase(res["text"])

        # build a flat, presentation-ready payload
        payload = {
            "kind": res["kind"],
            "answer": res["text"],
            "source": res.get("source"),
            "last_verified": res.get("last_verified"),
        }
        # the "Last updated from sources" line is appended by code for fact answers
        if res["kind"] in FACT_KINDS and res.get("last_verified"):
            payload["footer"] = f"Last updated from sources: {res['last_verified']}"
        return payload


if __name__ == "__main__":
    import json
    import sys

    g = Generator(Path(__file__).with_name("corpus.json"))
    q = " ".join(sys.argv[1:]) or "benchmark for HDFC Flexi Cap Fund"
    print(json.dumps(g.respond(q), indent=2, ensure_ascii=False))
