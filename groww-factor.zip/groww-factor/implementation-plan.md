# Implementation Plan

Phased plan with current status. All core phases are **done**; later phases are
optional hardening.

## Phase 0 — Scope & sources  ✅
- Pick AMC + 3 schemes (large-cap / flexi-cap / ELSS).
- Collect 15–25 official AMC/SEBI/AMFI URLs; verify each is live and on-domain.
- Record the renaming of HDFC Top 100 → HDFC Large Cap Fund (1 Jan 2025).
- **Output:** `sources` block in `corpus.json` (22 URLs).

## Phase 1 — Corpus  ✅
- Hand-curate ≤3-sentence facts per (scheme, topic), each with one `source_id`.
- Add `question_variants` per entry to feed the TF-IDF index.
- Keep volatile fields (NAV/TER/exit-load/min-SIP/manager) as concept + live link.
- **Output:** `corpus.json` (32 entries).

## Phase 2 — Retrieval + guardrails  ✅  (W1, W3)
- Rule-based intent: PII → advice → performance → retrieval → help → scope.
- Deterministic `scheme_topic` lookup with `general_topic` fallback.
- Pure-Python TF-IDF cosine fallback (no external ML dep).
- **Output:** `retrieval.py`; verified by the edge-case matrix.

## Phase 3 — Generation  ✅  (W2)
- Grounded template response; citation + date appended by code.
- Optional, tightly-constrained LLM rephrase (`USE_LLM`) that cannot alter sources.
- **Output:** `generate.py`.

## Phase 4 — App  ✅
- FastAPI: `/` chat UI, `/ask`, `/meta`, `/health`.
- Welcome line + 3 examples + "Facts-only. No investment advice." + disclaimer footer.
- **Output:** `app.py` (smoke-tested end-to-end).

## Phase 5 — Freshness / ops  ✅
- `ingest.py`: re-verify sources, refresh `last_verified`, write report; on-domain guard.
- `scheduler.py`: APScheduler daily run for long-running hosts.
- `.github/workflows/dailyingestion.yml`: daily CI verification + auto-commit.

## Phase 6 — Optional hardening  ⬜
- Swap TF-IDF for sentence-embeddings (replace `Retriever._semantic` only).
- Add `pytest` suite from `edge-case.md`.
- Add multilingual input normalisation (answers stay in English).
- Per-figure deep-linking once HDFC exposes stable anchors.

## Skill mapping

- **W1 (think like a model):** the guardrail-first classifier in `retrieval.py`
  decides the exact fact and answer-vs-refuse before any lookup.
- **W2 (prompting / refusals / citations):** concise ≤3-sentence answers, four
  distinct safe-refusal templates, code-appended citations and dates.
- **W3 (RAG):** small curated corpus + TF-IDF retrieval with verbatim, accurate
  citations restricted to AMC/SEBI/AMFI.
