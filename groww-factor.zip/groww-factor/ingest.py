"""
ingest.py
---------
Source verification / freshness pipeline for the curated corpus.

What it does (honestly):
  * reads corpus.json,
  * fetches each unique official source URL (HDFC MF / SEBI / AMFI only),
  * records HTTP status, byte length and a content hash,
  * if a source responds 200, bumps last_verified on every entry citing it,
  * writes data/verification_report.json.

What it deliberately does NOT do: it never auto-writes new *facts*. Facts in
this corpus are hand-curated from official pages so citations stay accurate;
ingestion only checks that those pages are still live and stamps the date. A
human reviews flagged/changed sources before editing answers.

Usage:  python ingest.py            (verify + update timestamps)
        python ingest.py --check    (verify only, no writes; non-zero exit if any fail)
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent
CORPUS = BASE / "corpus.json"
REPORT = BASE / "data" / "verification_report.json"

ALLOWED_HOSTS = ("hdfcfund.com", "amfiindia.com", "sebi.gov.in")
HEADERS = {"User-Agent": "groww-factor-ingest/1.0 (+facts-only FAQ; contact: maintainer)"}
TIMEOUT = 20


def _allowed(url: str) -> bool:
    return any(h in url for h in ALLOWED_HOSTS)


def fetch(url: str) -> dict:
    rec = {"url": url, "ok": False, "status": None, "bytes": 0, "hash": None, "error": None}
    if not _allowed(url):
        rec["error"] = "host not in allow-list (official AMC/SEBI/AMFI only)"
        return rec
    try:
        resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        rec["status"] = resp.status_code
        rec["bytes"] = len(resp.content)
        rec["hash"] = hashlib.sha256(resp.content).hexdigest()[:16]
        rec["ok"] = resp.status_code == 200 and rec["bytes"] > 0
    except Exception as exc:  # network / TLS / timeout
        rec["error"] = f"{type(exc).__name__}: {exc}"
    return rec


def run(check_only: bool = False) -> int:
    corpus = json.loads(CORPUS.read_text(encoding="utf-8"))
    sources = corpus["sources"]
    today = dt.date.today().isoformat()

    results = {}
    for sid, src in sources.items():
        results[sid] = fetch(src["url"])
        status = results[sid]["status"] or results[sid]["error"]
        print(f"[{ 'OK ' if results[sid]['ok'] else 'FAIL' }] {sid:10s} {status}  {src['url']}")

    ok_ids = {sid for sid, r in results.items() if r["ok"]}
    updated = 0
    if not check_only:
        for entry in corpus["entries"]:
            if entry["source_id"] in ok_ids:
                if entry.get("last_verified") != today:
                    entry["last_verified"] = today
                    updated += 1
        if updated:
            corpus["meta"]["last_updated"] = today
            CORPUS.write_text(json.dumps(corpus, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    REPORT.parent.mkdir(parents=True, exist_ok=True)
    report = {
        "checked_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "sources_total": len(sources),
        "sources_ok": len(ok_ids),
        "entries_restamped": updated,
        "results": results,
    }
    REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"\nVerified {len(ok_ids)}/{len(sources)} sources; restamped {updated} entries. Report -> {REPORT}")

    failed = len(sources) - len(ok_ids)
    return 1 if (check_only and failed) else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Verify official sources & refresh corpus timestamps.")
    ap.add_argument("--check", action="store_true", help="verify only; exit non-zero if any source fails")
    args = ap.parse_args()
    sys.exit(run(check_only=args.check))
