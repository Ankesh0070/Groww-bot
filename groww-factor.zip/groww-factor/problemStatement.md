# Problem Statement

## Milestone

Build a small FAQ assistant that answers **facts** about mutual fund schemes —
expense ratio, exit load, minimum SIP, lock-in (ELSS), riskometer, benchmark, and
how to download statements — using **only official public pages**. Every answer
must include **one source link**. **No advice.**

## Who it helps

- Retail investors comparing schemes.
- Support / content teams answering repetitive MF questions.

## Required behaviour

1. Answer **factual** queries only (expense ratio, ELSS lock-in, minimum SIP, exit
   load, riskometer/benchmark, how to download a capital-gains statement, etc.).
2. Show **one clear citation link** in every answer.
3. **Refuse** opinionated / portfolio questions ("Should I buy/sell?") politely,
   facts-only, with a relevant **educational link**.
4. Tiny UI: welcome line + 3 example questions + the note
   *"Facts-only. No investment advice."*

## Hard constraints

- **Public sources only.** No app back-end screenshots; no third-party blogs as sources.
- **No PII.** Never accept/store PAN, Aadhaar, account numbers, OTPs, emails or phone.
- **No performance claims.** Don't compute/compare returns; link to the official factsheet.
- **Clarity & transparency.** Answers ≤ 3 sentences; add "Last updated from sources: <date>".

## Scope chosen

- **AMC:** HDFC Mutual Fund.
- **Schemes:** HDFC Large Cap Fund (large-cap, formerly HDFC Top 100, renamed
  1 Jan 2025), HDFC Flexi Cap Fund (flexi-cap), HDFC ELSS Tax Saver (ELSS).
- **Sources:** 22 official HDFC MF / SEBI / AMFI pages (see `sources` in
  `corpus.json` and the project source list).

## Skills being demonstrated

- **W1 — Thinking like a model:** identify the exact fact asked; decide answer vs. refuse.
- **W2 — LLMs & prompting:** concise instructions, safe refusals, citation wording.
- **W3 — RAG:** small-corpus retrieval with accurate citations from AMC/SEBI/AMFI pages.

## Deliverables (this repo)

- Working prototype (FastAPI app + offline retriever) — `app.py`, `retrieval.py`,
  `generate.py`, `corpus.json`.
- Source list — the `sources` block in `corpus.json` (also exported as CSV in the
  companion submission).
- README with setup, scope and known limits — `README.md`.
- Sample Q&A — see `edge-case.md` and the companion `sample_qa.md`.
- Disclaimer snippet — `corpus.json:meta.disclaimer`, shown in the UI footer.
