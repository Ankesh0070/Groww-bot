"""
retrieval.py
------------
Small-corpus retrieval for groww-factor (RAG without a vector DB).

Two stages, in priority order:
  1. Guardrail / intent classification (rule-based regex) -> decides
     answer vs refuse BEFORE any retrieval (PII, advice, performance).
  2. Retrieval -> (a) deterministic scheme+topic lookup, then
     (b) a pure-Python TF-IDF cosine fallback over question_variants+answer.

No third-party ML dependency is required; the TF-IDF implementation is
self-contained so the bot runs fully offline and citations are always
pulled verbatim from the curated corpus (never generated).
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Optional


# --------------------------------------------------------------------------- #
# Guardrail patterns
# --------------------------------------------------------------------------- #
PII_PATTERNS = [
    re.compile(r"[A-Za-z]{5}\d{4}[A-Za-z]"),            # PAN
    re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),           # Aadhaar
    re.compile(r"\b(?:\+91[-\s]?)?[6-9]\d{9}\b"),       # phone
    re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"),        # email
    re.compile(r"\botp\b", re.I),                       # otp
    re.compile(r"\b\d{9,}\b"),                          # long account-like number
]

ADVICE_RE = re.compile(
    r"should i|should we|shall i|is it (a )?(good|bad|safe|worth)|worth (it|investing|buying)|"
    r"recommend|suggest( a| me)|which (fund|one|scheme) (is|should)|better than|which is better|"
    r"best (fund|scheme|option)|top fund|\bbuy\b|\bsell\b|redeem now|exit now|good time|right time|"
    r"invest now|do you think|your opinion|advi[cs]e|hold or|book profit|will it (go|rise|fall|grow)",
    re.I,
)

PERF_RE = re.compile(
    r"\breturn(s)?\b|\bcagr\b|how (much )?(profit|gain)|performance|how (has|did).*(perform)|"
    r"grew|growth rate|best performing|future|forecast|predict|outperform",
    re.I,
)

MF_SIGNAL_RE = re.compile(
    r"hdfc|mutual fund|\bmf\b|\belss\b|\bsip\b|\bnav\b|\bfund\b|scheme|80\s?c", re.I
)

SCHEME_RULES = [
    ("largecap", re.compile(r"top\s?100|large[-\s]?cap|largecap", re.I)),
    ("flexicap", re.compile(r"flexi", re.I)),
    ("elss", re.compile(r"elss|tax[-\s]?saver|80\s?c\b", re.I)),
]

# order matters (capgains before statement, ter keywords, etc.)
TOPIC_RULES = [
    ("capgains", re.compile(r"capital[-\s]?gain|cap gain|tax statement", re.I)),
    ("statement", re.compile(r"account statement|consolidated account|\bcas\b|download.*statement|\bstatement\b", re.I)),
    ("exitload", re.compile(r"exit load", re.I)),
    ("entryload", re.compile(r"entry load", re.I)),
    ("lockin", re.compile(r"lock[-\s]?in|lockin", re.I)),
    ("ter", re.compile(r"expense ratio|\bter\b|expense|cost|\bfee(s)?\b|charges", re.I)),
    ("minsip", re.compile(r"minimum|min\.?\s?sip|min\.?\s?invest|smallest|how much.*(start|invest)", re.I)),
    ("risk", re.compile(r"riskometer|risk level|how risky|\brisk\b", re.I)),
    ("benchmark", re.compile(r"benchmark|which index|index against", re.I)),
    ("nav", re.compile(r"\bnav\b|net asset value", re.I)),
    ("manager", re.compile(r"fund manager|managed by|who manages|who runs|manager", re.I)),
    ("category", re.compile(r"category|what type|what kind|overview|about the fund|tell me about", re.I)),
]

_TOKEN_RE = re.compile(r"[a-z0-9]+")
_STOP = {
    "the", "a", "an", "is", "are", "of", "for", "to", "in", "on", "and", "or",
    "what", "which", "how", "do", "does", "i", "my", "me", "you", "it", "this",
    "that", "with", "about", "can", "tell", "give", "please",
}


def _tokens(text: str) -> list[str]:
    return [t for t in _TOKEN_RE.findall(text.lower()) if t not in _STOP and len(t) > 1]


class Retriever:
    """Loads the corpus and answers a query with a grounded, cited response."""

    def __init__(self, corpus_path: str | Path = "corpus.json", semantic_threshold: float = 0.12):
        self.corpus_path = Path(corpus_path)
        self.semantic_threshold = semantic_threshold
        self.reload()

    # -- corpus loading & index build ------------------------------------- #
    def reload(self) -> None:
        data = json.loads(self.corpus_path.read_text(encoding="utf-8"))
        self.meta = data["meta"]
        self.sources = data["sources"]
        self.entries = data["entries"]
        self._by_id = {e["id"]: e for e in self.entries}
        self._build_tfidf()

    def _build_tfidf(self) -> None:
        docs = []
        for e in self.entries:
            text = " ".join(e.get("question_variants", [])) + " " + e["answer"]
            docs.append(_tokens(text))
        self._doc_tokens = docs
        df: Counter = Counter()
        for toks in docs:
            for t in set(toks):
                df[t] += 1
        n = len(docs)
        self._idf = {t: math.log((1 + n) / (1 + c)) + 1.0 for t, c in df.items()}
        self._doc_vecs = [self._vec(toks) for toks in docs]

    def _vec(self, toks: list[str]) -> dict[str, float]:
        tf = Counter(toks)
        vec = {t: (c / len(toks)) * self._idf.get(t, 0.0) for t, c in tf.items() if t in self._idf}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        return {t: v / norm for t, v in vec.items()}

    @staticmethod
    def _cosine(a: dict[str, float], b: dict[str, float]) -> float:
        if len(a) > len(b):
            a, b = b, a
        return sum(v * b.get(t, 0.0) for t, v in a.items())

    # -- detection helpers ------------------------------------------------- #
    @staticmethod
    def detect_scheme(t: str) -> Optional[str]:
        for name, rule in SCHEME_RULES:
            if rule.search(t):
                return name
        return None

    @staticmethod
    def detect_topic(t: str) -> Optional[str]:
        for name, rule in TOPIC_RULES:
            if rule.search(t):
                return name
        return None

    def _semantic(self, query: str):
        qvec = self._vec(_tokens(query))
        best, best_score = None, 0.0
        for entry, dvec in zip(self.entries, self._doc_vecs):
            s = self._cosine(qvec, dvec)
            if s > best_score:
                best, best_score = entry, s
        return best, best_score

    def _src(self, source_id: str) -> dict:
        return self.sources[source_id]

    def _answer_entry(self, entry: dict) -> dict:
        return {
            "kind": "answer",
            "text": entry["answer"],
            "source": self._src(entry["source_id"]),
            "last_verified": entry.get("last_verified", self.meta.get("last_updated")),
            "entry_id": entry["id"],
        }

    # -- main entry point -------------------------------------------------- #
    def answer(self, query: str) -> dict:
        raw = query or ""
        t = raw.lower().strip()

        # 1) PII guard (safety first)
        if any(p.search(raw) for p in PII_PATTERNS):
            return {
                "kind": "pii",
                "text": ("For your safety, please don't share personal details like PAN, Aadhaar, "
                         "account numbers, OTPs, email or phone. I don't collect or store any personal "
                         "data - I only answer general factual questions about HDFC mutual fund schemes."),
                "source": self._src("kyc"),
                "last_verified": None,
            }

        # 2) advice / opinion / portfolio -> refuse + educational link
        if ADVICE_RE.search(t):
            return {
                "kind": "advice",
                "text": ("I can't help with that - this is a facts-only assistant and I don't give "
                         "buy/sell, suitability or portfolio advice. For unbiased investor education, "
                         "SEBI's investor portal is a good place to start, and please consult a "
                         "SEBI-registered adviser for personal decisions."),
                "source": self._src("sebiEdu"),
                "last_verified": None,
            }

        scheme = self.detect_scheme(t)
        topic = self.detect_topic(t)

        # 3) performance / returns -> no performance claims, point to factsheet
        if PERF_RE.search(t) and topic != "benchmark":
            return {
                "kind": "performance",
                "text": ("I don't compute or compare returns or make performance claims. You can view "
                         "the official past performance of HDFC schemes in their latest factsheet."),
                "source": self._src("factsheet"),
                "last_verified": None,
            }

        # 4) deterministic retrieval: scheme+topic, then general+topic
        if topic:
            for key in (f"{scheme}_{topic}" if scheme else None, f"general_{topic}"):
                if key and key in self._by_id:
                    return self._answer_entry(self._by_id[key])

        # 4b) scheme named but no clear topic -> category overview
        if scheme and f"{scheme}_category" in self._by_id:
            return self._answer_entry(self._by_id[f"{scheme}_category"])

        # 4c) semantic fallback over the corpus
        best, score = self._semantic(raw)
        if best and score >= self.semantic_threshold:
            return self._answer_entry(best)

        # 5) in-scope but unresolved -> gentle, still-scoped help
        if scheme or topic or MF_SIGNAL_RE.search(t):
            return {
                "kind": "help",
                "text": ("I can share facts on HDFC Large Cap, Flexi Cap and ELSS Tax Saver funds - "
                         "things like expense ratio, exit load, lock-in, riskometer, benchmark, minimum "
                         "SIP, and how to download statements. Could you ask about one of those for a "
                         "specific scheme?"),
                "source": None,
                "last_verified": None,
            }

        # 6) out of scope
        return {
            "kind": "scope",
            "text": ("I can't answer that - I only provide factual information about HDFC mutual fund "
                     "schemes (Large Cap, Flexi Cap and ELSS Tax Saver)."),
            "source": None,
            "last_verified": None,
        }


if __name__ == "__main__":
    import sys

    r = Retriever(Path(__file__).with_name("corpus.json"))
    q = " ".join(sys.argv[1:]) or "What is the lock-in period for HDFC ELSS Tax Saver?"
    print(json.dumps(r.answer(q), indent=2, ensure_ascii=False))
