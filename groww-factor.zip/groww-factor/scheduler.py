"""
scheduler.py
------------
Runs the source-verification pipeline (ingest.run) on a daily schedule using
APScheduler. Useful for a long-running deployment that isn't on GitHub Actions.

Config (env):
  INGEST_HOUR   hour of day, 0-23   (default 3)
  INGEST_MINUTE minute, 0-59        (default 0)
  TZ            timezone name       (default Asia/Kolkata)

Usage:  python scheduler.py
"""

from __future__ import annotations

import os

from apscheduler.schedulers.blocking import BlockingScheduler

import ingest


def job() -> None:
    print(">> running daily source verification")
    ingest.run(check_only=False)


def main() -> None:
    hour = int(os.getenv("INGEST_HOUR", "3"))
    minute = int(os.getenv("INGEST_MINUTE", "0"))
    tz = os.getenv("TZ", "Asia/Kolkata")

    sched = BlockingScheduler(timezone=tz)
    sched.add_job(job, "cron", hour=hour, minute=minute, id="daily_ingest")
    print(f"Scheduler started: daily at {hour:02d}:{minute:02d} {tz}. Running one pass now...")
    job()  # run once on boot
    try:
        sched.start()
    except (KeyboardInterrupt, SystemExit):
        print("Scheduler stopped.")


if __name__ == "__main__":
    main()
